class Node:
    def __init__(self, value=None, next=None):
        self.value = value
        self.next = next

class LinkedList:
    def __init__(self,head):
        self.head = head

    def insert(self,value):
        newNode = Node(value)
        if self.head == None:
            self.head = newNode
        else:
            current = self.head
            while current.next != None:
                current = current.next
            current.next = newNode
    def count(self)->int:
        counter = 0
        current = self.head
        while current != None:
            counter += 1
            current = current.next

        return counter

    def delete(self, index) -> bool:
        if index < 1 or index > self.count():
            return False

        # İlk node siliniyorsa
        if index == 1:
            self.head = self.head.next
            return True  # return koymayı unutmayın

        current = self.head
        for i in range(index - 2):
            current = current.next

        # current artık silinecek düğümün bir önceki
        current.next = current.next.next
        return True

    def isEmpty(self):
        return self.head == None

    def printlist(self):
        current = self.head
        while current != None:
            print(current.value, "->")
            current = current.next


