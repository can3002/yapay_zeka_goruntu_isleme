class LineerSearch:
    def ara(self,liste):
        bulundu = False
        aranan = int(input("Aranacak bir eleman giriniz: "))
        self.liste = []
        for i in range(len(liste)):
            if liste[i] == aranan:
                print(f"Aranan değer bulundu {liste[i]} {i}. indexte")
                bulundu = True
                break
        if not bulundu:
            bulundu = False
            print("Böyle bir değer yok")

l = LineerSearch()
sonuc = l.ara([1,4,56,78,69,800,543,33,31,25,66])

